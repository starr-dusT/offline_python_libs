pytest-3.0.2
============

pytest 3.0.2 has just been released to PyPI.

This release fixes some regressions and bugs reported in version 3.0.1, being a
drop-in replacement. To upgrade::

  pip install --upgrade pytest

The changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* Ahn Ki-Wook
* Bruno Oliveira
* Florian Bruhin
* Jordan Guymon
* Raphael Pierzina
* Ronny Pfannschmidt
* mbyt

Happy testing,
The pytest Development Team
