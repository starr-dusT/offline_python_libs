def pytest_ignore_collect(path):
    return False
